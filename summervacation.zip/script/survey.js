document.getElementById("q4").addEventListener("change", function () {
  const q4_1_wrapper = document.getElementById("q4-1-wrapper");
  const q4_2_wrapper = document.getElementById("q4-2-wrapper");

  if (this.value === "국내") {
    q4_1_wrapper.style.display = "block";
    q4_2_wrapper.style.display = "none";
    document.getElementById("q4-2").value = "";
  } else if (this.value === "해외") {
    q4_2_wrapper.style.display = "block";
    q4_1_wrapper.style.display = "none";
    document.getElementById("q4-1").value = "";
  } else {
    q4_1_wrapper.style.display = "none";
    q4_2_wrapper.style.display = "none";
    document.getElementById("q4-1").value = "";
    document.getElementById("q4-2").value = "";
  }
});

document.getElementById("surveyForm").addEventListener("submit", function (e) {
  e.preventDefault();
  let allAnswered = true;
  let firstUnanswered = null;

  const answers = {};

  for (let i = 1; i <= 10; i++) {
    const select = document.getElementById(`q${i}`);
    const errorMsg = document.getElementById(`error-q${i}`);

    if (select && select.value === "") {
      allAnswered = false;
      errorMsg.textContent = `${i}번 질문에 응답해주세요.`;
      if (!firstUnanswered) firstUnanswered = i;
    } else {
      errorMsg.textContent = "";
      answers[`q${i}`] = select.value;
    }
  }

  const q4 = document.getElementById("q4");
  const q4_1 = document.getElementById("q4-1");
  const q4_2 = document.getElementById("q4-2");
  const error_q4_1 = document.getElementById("error-q4-1");
  const error_q4_2 = document.getElementById("error-q4-2");

  if (q4.value === "국내") {
    if (q4_1.value === "") {
      allAnswered = false;
      error_q4_1.textContent = "4-1번 질문에 응답해주세요.";
      if (!firstUnanswered) firstUnanswered = "4-1";
    } else {
      error_q4_1.textContent = "";
      answers["q4-1"] = q4_1.value;
    }
  } else if (q4.value === "해외") {
    if (q4_2.value === "") {
      allAnswered = false;
      error_q4_2.textContent = "4-2번 질문에 응답해주세요.";
      if (!firstUnanswered) firstUnanswered = "4-2";
    } else {
      error_q4_2.textContent = "";
      answers["q4-2"] = q4_2.value;
    }
  }

  if (!allAnswered) {
    alert(`${firstUnanswered}번 질문부터 응답해주세요.`);
    const scrollTargetId = `q${firstUnanswered.toString().replace("-", "-")}`;
    document.getElementById(scrollTargetId)?.scrollIntoView({ behavior: "smooth" });
    return;
  }

  // ✅ 백엔드로 설문 데이터 전송
  fetch("https://dt5857.pythonanywhere.com/api/survey/", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(answers),
  })
    .then((res) => {
      if (!res.ok) {
        throw new Error(`서버 응답 오류: ${res.status}`);
      }
      return res.json();
    })
    .then((data) => {
      if (data.success) {
        alert("설문조사가 완료되었습니다.");
        window.location.href = "result.html";
      } else {
        alert("설문 제출에 실패했습니다. 다시 시도해주세요.");
      }
    })
    .catch((err) => {
      console.error("설문 제출 중 오류 발생:", err);
      alert("서버 오류가 발생했습니다. 나중에 다시 시도해주세요.");
    });
});
