document.getElementById("loginForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const userid = document.getElementById("login-userid").value.trim();
  const password = document.getElementById("login-password").value.trim();
  const useridError = document.getElementById("userid-error");
  const passwordError = document.getElementById("password-error");

  // 에러 메시지 초기화
  useridError.textContent = "";
  passwordError.textContent = "";

  // 입력 유효성 검사
  if (!userid) {
    useridError.textContent = "아이디를 입력해주세요.";
    return;
  }

  if (!password) {
    passwordError.textContent = "비밀번호를 입력해주세요.";
    return;
  }

  // 로그인 요청 (백엔드 API로 POST 요청)
  fetch("https://dt5857.pythonanywhere.com/api/login/", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ userid, password }),
  })
    .then((res) => {
      if (!res.ok) {
        throw new Error("HTTP 오류: " + res.status);
      }
      return res.json();
    })
    .then((data) => {
      if (data.success) {
        // 로그인 성공 시
        window.location.href = "survey.html"; // 다음 페이지로 이동
      } else {
        // 로그인 실패 시 에러 처리
        if (data.error === "no_user") {
          useridError.textContent = "존재하지 않는 아이디입니다.";
        } else if (data.error === "wrong_password") {
          passwordError.textContent = "비밀번호가 일치하지 않습니다.";
        } else {
          passwordError.textContent = "로그인에 실패했습니다. 다시 시도해주세요.";
        }
      }
    })
    .catch((err) => {
      console.error("로그인 요청 중 오류 발생:", err);
      passwordError.textContent = "서버 오류가 발생했습니다. 다시 시도해주세요.";
    });
});
