let idAvailable = false; // 사용 안 하니까 나중에 지워도 됨

function showIdStatus(message, isError = true) {
  const status = document.getElementById("idStatus");
  status.innerText = message;
  status.style.color = isError ? "red" : "green";
  if (message) {
    status.classList.add("visible");
  } else {
    status.classList.remove("visible");
  }
}

function showError(inputId, message) {
  const errorEl = document.getElementById(inputId + "-error");
  errorEl.textContent = message;
  if (message) {
    errorEl.classList.add("visible");
  } else {
    errorEl.classList.remove("visible");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  const nameInput = document.getElementById("name");

  nameInput.addEventListener("input", () => {
    const value = nameInput.value;
    const invalid = /[^\uAC00-\uD7A3]/.test(value);

    if (value === "") {
      showError("name", "");
    } else if (invalid) {
      showError("name", "한글만 입력 가능합니다");
    } else {
      showError("name", "");
    }
  });

  const useridInput = document.getElementById("userid");
  useridInput.addEventListener("input", () => {
    if (/[가-힣]/.test(useridInput.value)) {
      showError("userid", "아이디에는 한글을 사용할 수 없습니다.");
    } else {
      showError("userid", "");
    }
    showIdStatus("");
    idAvailable = false;
  });

  const passwordInput = document.getElementById("password");
  let capsLockTooltip = null;

  passwordInput.addEventListener("keyup", (e) => {
    if (e.getModifierState && e.getModifierState("CapsLock")) {
      if (!capsLockTooltip) {
        capsLockTooltip = document.createElement("div");
        capsLockTooltip.textContent = "Caps Lock이 켜져 있습니다!";
        capsLockTooltip.style.position = "absolute";
        capsLockTooltip.style.color = "red";
        capsLockTooltip.style.background = "lightyellow";
        capsLockTooltip.style.border = "1px solid red";
        capsLockTooltip.style.padding = "5px";
        capsLockTooltip.style.borderRadius = "5px";
        capsLockTooltip.style.top = passwordInput.offsetTop - 30 + "px";
        capsLockTooltip.style.left = passwordInput.offsetLeft + "px";
        capsLockTooltip.classList.add("caps-tooltip");
        passwordInput.parentElement.appendChild(capsLockTooltip);
      }
    } else {
      if (capsLockTooltip) {
        capsLockTooltip.remove();
        capsLockTooltip = null;
      }
    }
    showError("password", "");
  });

  passwordInput.addEventListener("blur", () => {
    if (capsLockTooltip) {
      capsLockTooltip.remove();
      capsLockTooltip = null;
    }
  });

  const password2Input = document.getElementById("password2");
  let capsLockTooltip2 = null;

  password2Input.addEventListener("keyup", (e) => {
    if (e.getModifierState && e.getModifierState("CapsLock")) {
      if (!capsLockTooltip2) {
        capsLockTooltip2 = document.createElement("div");
        capsLockTooltip2.textContent = "Caps Lock이 켜져 있습니다!";
        capsLockTooltip2.style.position = "absolute";
        capsLockTooltip2.style.color = "red";
        capsLockTooltip2.style.background = "lightyellow";
        capsLockTooltip2.style.border = "1px solid red";
        capsLockTooltip2.style.padding = "5px";
        capsLockTooltip2.style.borderRadius = "5px";
        capsLockTooltip2.style.top = password2Input.offsetTop - 30 + "px";
        capsLockTooltip2.style.left = password2Input.offsetLeft + "px";
        capsLockTooltip2.classList.add("caps-tooltip");
        password2Input.parentElement.appendChild(capsLockTooltip2);
      }
    } else {
      if (capsLockTooltip2) {
        capsLockTooltip2.remove();
        capsLockTooltip2 = null;
      }
    }
    showError("password2", "");
  });

  password2Input.addEventListener("blur", () => {
    if (capsLockTooltip2) {
      capsLockTooltip2.remove();
      capsLockTooltip2 = null;
    }
  });

  const ageInput = document.getElementById("age");
  ageInput.addEventListener("input", () => {
    ageInput.value = ageInput.value.replace(/[^0-9]/g, "");
    showError("age", "");
  });

  const emailInput = document.getElementById("email");
  emailInput.addEventListener("input", () => {
    emailInput.value = emailInput.value.replace(/[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/g, "");
    showError("email", "");
  });
});

document
  .getElementById("registerForm")
  .addEventListener("submit", async function (e) {
    e.preventDefault();

    ["name", "userid", "password", "password2", "age", "email"].forEach((id) =>
      showError(id, "")
    );
    showIdStatus("");

    const name = document.getElementById("name").value.trim();
    const userid = document.getElementById("userid").value.trim();
    const password = document.getElementById("password").value.trim();
    const password2 = document.getElementById("password2").value.trim();
    const age = document.getElementById("age").value.trim();
    const email = document.getElementById("email").value.trim();

    if (!name) {
      showError("name", "이름을 입력해주세요.");
      document.getElementById("name").focus();
      return;
    }
    if (!/^[가-힣]+$/.test(name)) {
      showError("name", "이름은 한글만 입력 가능합니다.");
      document.getElementById("name").focus();
      return;
    }

    if (!userid) {
      showError("userid", "아이디를 입력해주세요.");
      document.getElementById("userid").focus();
      return;
    }
    if (/[가-힣]/.test(userid)) {
      showError("userid", "아이디에는 한글을 사용할 수 없습니다.");
      document.getElementById("userid").focus();
      return;
    }

    if (!password) {
      showError("password", "비밀번호를 입력해주세요.");
      document.getElementById("password").focus();
      return;
    }
    if (!password2) {
      showError("password2", "비밀번호 확인을 입력해주세요.");
      document.getElementById("password2").focus();
      return;
    }
    if (password !== password2) {
      showError("password2", "비밀번호가 일치하지 않습니다.");
      document.getElementById("password2").focus();
      return;
    }

    if (!age) {
      showError("age", "나이를 입력해주세요.");
      document.getElementById("age").focus();
      return;
    }
    if (!/^\d+$/.test(age)) {
      showError("age", "나이는 숫자만 입력 가능합니다.");
      document.getElementById("age").focus();
      return;
    }

    // 이메일 검사
    if (!email) {
      showError("email", "이메일을 입력해주세요.");
      document.getElementById("email").focus();
      return;
    }
    if (/[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/.test(email)) {
      showError("email", "이메일에 한글을 포함할 수 없습니다.");
      document.getElementById("email").focus();
      return;
    }
    if (!email.includes("@")) {
      showError("email", "이메일 형식이 올바르지 않습니다. '@'를 포함해야 합니다.");
      document.getElementById("email").focus();
      return;
    }

    try {
      const response = await fetch("https://dt5857.pythonanywhere.com/api/register/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name,
          userid,
          password,
          password_confirm : password2,
          age,
          email,
        }),
      });

      const result = await response.json();

      if (response.ok) {
        alert("✅ 회원가입 성공: " + (result.message || "환영합니다!"));
      } else {
        alert("❌ 회원가입 실패: " + (result.message || "다시 시도해주세요."));
      }
    } catch (error) {
      alert("🚨 서버 요청 실패: " + error.message);
    }
  });
